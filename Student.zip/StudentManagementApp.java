import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StudentManagementApp {
    private List<Student> students;
    private final String FILE_PATH = "data/students.txt";

    public StudentManagementApp() {
        students = new ArrayList<>();
        loadStudentsFromFile();
    }

    // Add a new student
    public void addStudent(Student student) {
        students.add(student);
        saveStudentsToFile();
    }

    // Get all students
    public List<Student> getAllStudents() {
        return students;
    }

    // Find student by roll number
    public Student findStudentByRollNo(String rollNo) {
        for (Student student : students) {
            if (student.getRollNo().equals(rollNo)) {
                return student;
            }
        }
        return null;
    }

    // Update student
    public void updateStudent(Student student) {
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getRollNo().equals(student.getRollNo())) {
                students.set(i, student);
                saveStudentsToFile();
                break;
            }
        }
    }

    // Delete student
    public void deleteStudent(String rollNo) {
        students.removeIf(student -> student.getRollNo().equals(rollNo));
        saveStudentsToFile();
    }

    // Load students from file
    private void loadStudentsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                students.add(new Student(data[0], Integer.parseInt(data[1]), data[2], data[3]));
            }
        } catch (IOException e) {
            System.out.println("Error loading students from file.");
        }
    }

    // Save students to file
    private void saveStudentsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Student student : students) {
                writer.write(student.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving students to file.");
        }
    }
}
