import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudentManagementUI extends JFrame {
    private StudentManagementApp app;
    private JTextField nameField, ageField, rollNoField, courseField;
    private JTextArea displayArea;

    public StudentManagementUI() {
        app = new StudentManagementApp();

        // UI components
        JLabel nameLabel = new JLabel("Name:");
        JLabel ageLabel = new JLabel("Age:");
        JLabel rollNoLabel = new JLabel("Roll No:");
        JLabel courseLabel = new JLabel("Course:");

        nameField = new JTextField(20);
        ageField = new JTextField(5);
        rollNoField = new JTextField(10);
        courseField = new JTextField(15);

        JButton addButton = new JButton("Add Student");
        JButton viewButton = new JButton("View Students");
        JButton updateButton = new JButton("Update Student");
        JButton deleteButton = new JButton("Delete Student");

        displayArea = new JTextArea(10, 50);
        displayArea.setEditable(false);

        // Add components to layout
        JPanel panel = new JPanel();
        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(ageLabel);
        panel.add(ageField);
        panel.add(rollNoLabel);
        panel.add(rollNoField);
        panel.add(courseLabel);
        panel.add(courseField);
        panel.add(addButton);
        panel.add(viewButton);
        panel.add(updateButton);
        panel.add(deleteButton);

        JScrollPane scrollPane = new JScrollPane(displayArea);
        panel.add(scrollPane);

        // Add listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addStudent();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewStudents();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateStudent();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteStudent();
            }
        });

        // Frame settings
        this.add(panel);
        this.setTitle("Student Management Portal");
        this.setSize(600, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    // Add student to system
    private void addStudent() {
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String rollNo = rollNoField.getText();
        String course = courseField.getText();

        Student student = new Student(name, age, rollNo, course);
        app.addStudent(student);
        JOptionPane.showMessageDialog(this, "Student added successfully!");
        clearFields();
    }

    // View all students
    private void viewStudents() {
        List<Student> students = app.getAllStudents();
        displayArea.setText("");
        for (Student student : students) {
            displayArea.append(student.toString() + "\n");
        }
    }

    // Update student information
    private void updateStudent() {
        String rollNo = rollNoField.getText();
        Student student = app.findStudentByRollNo(rollNo);
        if (student != null) {
            student.setName(nameField.getText());
            student.setAge(Integer.parseInt(ageField.getText()));
            student.setCourse(courseField.getText());
            app.updateStudent(student);
            JOptionPane.showMessageDialog(this, "Student updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Student not found.");
        }
    }

    // Delete student
    private void deleteStudent() {
        String rollNo = rollNoField.getText();
        app.deleteStudent(rollNo);
        JOptionPane.showMessageDialog(this, "Student deleted successfully!");
    }

    // Clear input fields
    private void clearFields() {
        nameField.setText("");
        ageField.setText("");
        rollNoField.setText("");
        courseField.setText("");
    }

    public static void main(String[] args) {
        new StudentManagementUI();
    }
}
